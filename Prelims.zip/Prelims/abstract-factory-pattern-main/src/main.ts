import './style.css'
import { WindowsVMFactory, MacVMFactory, LinuxVMFactory, VirtualMachineFactory} from './abstract_factory'

//@ts-ignore
import windows_img from './windows_img.png'
//@ts-ignore
import mac_img from './mac_img.jpg'
//@ts-ignore
import linux_img from './linux_img.png'

document.querySelector<HTMLDivElement>('#app')!.innerHTML = `
  
  <body>
    <button id="windowsVirtualMachine">Create Windows Machine</button>
    <button id="macVirtualMachine">Create Mac Machine</button>
    <button id="linuxVirtualMachine"> Create Linux Machine<>
    <div id="vmResult"></div>

    <div>
      <img id="vmImage" src="" alt="Virtual Machine">
    </div>
  </body>

`


//Function to handle button click events
function handleButtonClick(factory: VirtualMachineFactory): void {
  
  let virtualMachine = factory.createVirtualMachine();
  let vmImageDiv = document.getElementById('vmImage') as HTMLImageElement

  if (virtualMachine && vmImageDiv) {
    let vmResultElement = document.getElementById("vmResult")
    if (vmResultElement) {
      vmResultElement.textContent = `Selected ${virtualMachine.getType()} virtual machine`;
      switch (virtualMachine.getType().toLowerCase()) {
        case 'windows':
          vmImageDiv.src = windows_img
          break;
        case 'mac':
          vmImageDiv.src = mac_img
          break;
        case 'linux':
          vmImageDiv.src = linux_img
          break;
        default:
          vmImageDiv.src = ''
      }
    }
  } else {
    let vmResultElement = document.getElementById('vmResult')
    if (vmResultElement) {
      vmResultElement.textContent = 'Invalid machine type'
    }
  }
}

//Add event listeners to the buttons

document.addEventListener('DOMContentLoaded', function() {
  let windowsButton = document.getElementById('windowsVirtualMachine')
  let macButton = document.getElementById('macVirtualMachine')
  let linuxButton = document.getElementById('linuxVirtualMachine')

  let windowsFactory = new WindowsVMFactory()
  let macFactory = new MacVMFactory()
  let linuxFactory = new LinuxVMFactory()

  if (windowsButton) {
    windowsButton.addEventListener('click', function() {
      handleButtonClick(windowsFactory)
    })
  }

  if (macButton) {
    macButton.addEventListener('click', function() {
      handleButtonClick(macFactory)
    })
  }
  
  if (linuxButton) {
    linuxButton.addEventListener('click', function() {
      handleButtonClick(linuxFactory)
    })
  }
})