//Abstract Product
abstract class VirtualMachine {
  abstract getType(): string;
  abstract start(): void
  abstract end(): void
}

//Concrete products
class WindowsVM extends VirtualMachine {

  getType(): string {
      return 'windows'
  }

  start(): void {
      console.log("Starting Windows Virtual Machine")
  }

  end(): void {
    console.log("Ending Windows Virtual Machine")
  }
}

class MacVM extends VirtualMachine {

  getType(): string {
      return 'Mac'
  }

  start(): void {
      console.log("Starting Mac Virtual Machine")
  }

  end(): void {
    console.log("Ending Mac Virtual Machine")
  }
}

class LinuxVM extends VirtualMachine {

  getType(): string {
      return 'Linux'
  }

  start(): void {
      console.log("Starting Linux Virtual Machine")
  }

  end(): void {
    console.log("Ending Linux Virtual Machine")
  }
}

//Abstract Factory
export abstract class VirtualMachineFactory {
  abstract createVirtualMachine(): VirtualMachine
}

//Concrete Factories
export class WindowsVMFactory extends VirtualMachineFactory {
  createVirtualMachine(): VirtualMachine {
      return new WindowsVM();
  }
}

export class MacVMFactory extends VirtualMachineFactory {
  createVirtualMachine(): VirtualMachine {
      return new MacVM();
  }
}

export class LinuxVMFactory extends VirtualMachineFactory {
  createVirtualMachine(): VirtualMachine {
      return new LinuxVM();
  }
}

