﻿# abstract-factory-pattern

instructions for launching:
1. npm install
2. npm run dev
